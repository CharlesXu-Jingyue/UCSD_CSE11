interface Command{
    String[] execute(String[] data);
}

class CmdTool{
    
}